package com.example.parqueadero;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import java.time.LocalDateTime;
import java.util.List;

@PageTitle("Reportes")
@Route(value = "reportes", layout = MainLayout.class)
public class ReportesView extends VerticalLayout {

    private static final String COLOR_NORMAL = "#1976d2";
    private static final String COLOR_PICO = "#c62828";

    private final Grid<IngresoDia> gridIngresos = new Grid<>();
    private final Span totalIngresos = new Span();
    private final Span textoHoraPico = new Span();
    private final VerticalLayout graficoOcupacion = new VerticalLayout();

    public ReportesView() {
        gridIngresos.addColumn(dia -> dia.getFecha().format(Utilidades.FORMATO_FECHA)).setHeader("Fecha");
        gridIngresos.addColumn(IngresoDia::getSalidas).setHeader("Salidas");
        gridIngresos.addColumn(dia -> Utilidades.formatearDinero(dia.getIngresos())).setHeader("Ingresos");
        gridIngresos.setWidthFull();
        gridIngresos.setHeight("20rem");

        totalIngresos.getStyle().set("font-weight", "bold");
        textoHoraPico.getStyle().set("font-weight", "bold");
        graficoOcupacion.setPadding(false);
        graficoOcupacion.setSpacing(false);
        graficoOcupacion.getStyle().set("gap", "4px");

        add(new H2("Reportes"),
                new H3("Ingresos por día"), gridIngresos, totalIngresos,
                new H3("Ocupación por hora"),
                new Span("Promedio de puestos ocupados en cada hora del día durante los últimos 7 días."),
                textoHoraPico, graficoOcupacion);
    }

    // Se recalculan los reportes cada vez que entras a la vista
    @Override
    protected void onAttach(AttachEvent evento) {
        List<Registro> registros = ArchivoParqueadero.leerRegistros();
        mostrarIngresosPorDia(registros);
        mostrarOcupacionPorHora(registros);
    }

    private void mostrarIngresosPorDia(List<Registro> registros) {
        List<IngresoDia> dias = Reportes.ingresosPorDia(registros);
        gridIngresos.setItems(dias);

        int total = 0;
        for (IngresoDia dia : dias) {
            total += dia.getIngresos();
        }
        totalIngresos.setText("Total general: " + Utilidades.formatearDinero(total));
    }

    private void mostrarOcupacionPorHora(List<Registro> registros) {
        double[] promedios = Reportes.ocupacionPorHora(registros, LocalDateTime.now());
        double maximo = Reportes.maximo(promedios);
        List<Integer> horasPico = Reportes.horasPico(promedios);

        if (horasPico.isEmpty()) {
            textoHoraPico.setText("Todavía no hay datos de ocupación en la última semana.");
        } else {
            String horas = "";
            for (int hora : horasPico) {
                if (!horas.isEmpty()) {
                    horas += ", ";
                }
                horas += String.format("%02d:00", hora);
            }
            textoHoraPico.setText("Hora pico: " + horas + " (promedio de "
                    + Utilidades.formatearDecimal(maximo) + " puestos ocupados).");
        }

        graficoOcupacion.removeAll();
        for (int hora = 0; hora < 24; hora++) {
            boolean esPico = horasPico.contains(hora);
            graficoOcupacion.add(crearFilaDeHora(hora, promedios[hora], maximo, esPico));
        }
    }

    // Una fila del gráfico: la hora, una barra cuyo largo es proporcional al promedio, y el valor
    private HorizontalLayout crearFilaDeHora(int hora, double promedio, double maximo, boolean esPico) {
        Span etiquetaHora = new Span(String.format("%02d:00", hora));
        etiquetaHora.setWidth("3.5rem");

        long porcentaje = (maximo > 0) ? Math.round(promedio / maximo * 100) : 0;
        Div barra = new Div();
        barra.getStyle()
                .set("width", porcentaje + "%")
                .set("height", "1rem")
                .set("border-radius", "3px")
                .set("background-color", esPico ? COLOR_PICO : COLOR_NORMAL);
        Div contenedorBarra = new Div(barra);
        contenedorBarra.getStyle().set("flex", "1");

        Span valor = new Span(Utilidades.formatearDecimal(promedio));
        valor.setWidth("3rem");

        HorizontalLayout fila = new HorizontalLayout(etiquetaHora, contenedorBarra, valor);
        fila.setWidthFull();
        fila.setSpacing(false);
        fila.setAlignItems(FlexComponent.Alignment.CENTER);
        return fila;
    }
}