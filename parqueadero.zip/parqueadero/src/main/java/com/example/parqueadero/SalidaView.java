package com.example.parqueadero;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@PageTitle("Registrar salida")
@Route(value = "salida", layout = MainLayout.class)
public class SalidaView extends VerticalLayout {

    private final TextField campoPlaca = Utilidades.crearCampoPlaca();

    public SalidaView() {
        Span tarifas = new Span(describirTarifas());

        Button botonSalida = new Button("Registrar salida", evento -> registrarSalida());
        botonSalida.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

        setMaxWidth("28rem");
        add(new H2("Registrar salida"), tarifas, campoPlaca, botonSalida);
    }

    private void registrarSalida() {
        String placa = campoPlaca.getValue().trim().toUpperCase();

        // 1. Validar la placa y que el vehículo realmente esté adentro
        if (!Utilidades.esPlacaValida(placa)) {
            Utilidades.mostrarError("Escribe una placa válida (5 a 7 letras o números).");
            return;
        }

        List<Registro> registros = ArchivoParqueadero.leerRegistros();
        Registro registro = Registro.buscarActivoPorPlaca(registros, placa);
        if (registro == null) {
            Utilidades.mostrarError("La placa " + placa + " no está dentro del parqueadero.");
            return;
        }

        // 2. Calcular el cobro: con mensualidad vigente no se paga
        LocalDateTime ahora = LocalDateTime.now().withNano(0);
        boolean conMensualidad = tieneMensualidadVigente(placa, ahora.toLocalDate());
        int total = 0;
        if (!conMensualidad) {
            total = Tarifa.calcularValor(registro, ahora);
        }

        // 3. Guardar la salida
        registro.registrarSalida(ahora, total);
        if (!ArchivoParqueadero.guardarRegistros(registros)) {
            Utilidades.mostrarError("No se pudo guardar la salida. Intenta de nuevo.");
            return;
        }

        campoPlaca.clear();
        mostrarRecibo(registro, conMensualidad);
    }

    private String describirTarifas() {
        if (Tarifa.COBRO_POR_MINUTOS) {
            return "Los primeros " + Tarifa.MINUTOS_GRATIS + " minutos son gratis. Después: carro "
                    + Utilidades.formatearDinero(Tarifa.CARRO_POR_MINUTO) + " por minuto (tope "
                    + Utilidades.formatearDinero(Tarifa.CARRO_TOPE_POR_DIA) + " por día), moto "
                    + Utilidades.formatearDinero(Tarifa.MOTO_POR_MINUTO) + " por minuto (tope "
                    + Utilidades.formatearDinero(Tarifa.MOTO_TOPE_POR_DIA) + " por día). "
                    + "Si el vehículo pasa la noche, cada día se cobra por separado.";
        }
        return "Tarifa por hora: carro " + Utilidades.formatearDinero(Tarifa.CARRO_POR_HORA)
                + ", moto " + Utilidades.formatearDinero(Tarifa.MOTO_POR_HORA)
                + ". La fracción de hora se cobra como hora completa.";
    }

    private boolean tieneMensualidadVigente(String placa, LocalDate fecha) {
        for (Mensualidad mensualidad : ArchivoParqueadero.leerMensualidades()) {
            if (mensualidad.getPlaca().equals(placa) && mensualidad.estaVigente(fecha)) {
                return true;
            }
        }
        return false;
    }

    private void mostrarRecibo(Registro registro, boolean conMensualidad) {
        Dialog dialogo = new Dialog();
        dialogo.setHeaderTitle("Recibo de salida");

        VerticalLayout contenido = new VerticalLayout(
                new Span("Placa: " + registro.getPlaca()),
                new Span("Tipo: " + registro.getTipo()),
                new Span("Puesto: fila " + registro.getFila() + ", columna " + registro.getColumna()),
                new Span("Entrada: " + registro.getHoraEntrada().format(Utilidades.FORMATO_FECHA_HORA)),
                new Span("Salida: " + registro.getHoraSalida().format(Utilidades.FORMATO_FECHA_HORA)),
                new Span("Tiempo: " + registro.tiempoTranscurrido(registro.getHoraSalida())));
        contenido.setPadding(false);
        contenido.setSpacing(false);

        if (conMensualidad) {
            contenido.add(new Span("Mensualidad vigente: no se cobra."));
        } else if (Tarifa.COBRO_POR_MINUTOS) {
            String tipo = registro.getTipo();
            contenido.add(new Span("Minutos gratis: " + Tarifa.MINUTOS_GRATIS));
            contenido.add(new Span("Tarifa: " + Utilidades.formatearDinero(Tarifa.porMinuto(tipo))
                    + " por minuto, tope " + Utilidades.formatearDinero(Tarifa.topePorDia(tipo)) + " por día"));
        } else {
            int horas = registro.horasACobrar(registro.getHoraSalida());
            int tarifa = Tarifa.porHora(registro.getTipo());
            contenido.add(new Span("Horas cobradas: " + horas + " x " + Utilidades.formatearDinero(tarifa)));
        }

        Span total = new Span("Total a pagar: " + Utilidades.formatearDinero(registro.getValorCobrado()));
        total.getStyle().set("font-weight", "bold").set("margin-top", "0.5rem");
        contenido.add(total);

        dialogo.add(contenido);
        dialogo.getFooter().add(new Button("Cerrar", evento -> dialogo.close()));
        dialogo.open();
    }
}