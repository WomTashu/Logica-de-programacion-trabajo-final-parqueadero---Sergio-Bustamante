package com.example.parqueadero;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;

public class MainLayout extends AppLayout {

    public MainLayout() {
        H1 titulo = new H1("Parqueadero");
        titulo.getStyle().set("font-size", "1.25rem").set("margin", "0");

        SideNav menu = new SideNav();
        menu.addItem(new SideNavItem("Plano", PlanoView.class));
        menu.addItem(new SideNavItem("Registrar entrada", EntradaView.class));
        menu.addItem(new SideNavItem("Registrar salida", SalidaView.class));
        menu.addItem(new SideNavItem("Mensualidades", MensualidadesView.class));

        addToNavbar(new DrawerToggle(), titulo);
        addToDrawer(menu);
    }
}