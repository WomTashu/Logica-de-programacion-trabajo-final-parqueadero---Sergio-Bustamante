package com.example.parqueadero;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
 
import java.time.LocalDateTime;
import java.util.List;
 
@PageTitle("Registrar entrada")
@Route(value = "entrada", layout = MainLayout.class)
public class EntradaView extends VerticalLayout {
 
    private final TextField campoPlaca = new TextField("Placa");
    private final Select<String> selectTipo = new Select<>();
 
    public EntradaView() {
        campoPlaca.setPlaceholder("ABC123");
        campoPlaca.setMaxLength(7);
        campoPlaca.setAllowedCharPattern("[A-Za-z0-9]");
 
        selectTipo.setLabel("Tipo de vehículo");
        selectTipo.setItems("CARRO", "MOTO");
 
        Button botonRegistrar = new Button("Registrar entrada", evento -> registrarEntrada());
        botonRegistrar.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
 
        setMaxWidth("28rem");
        add(new H2("Registrar entrada"), campoPlaca, selectTipo, botonRegistrar);
    }
 
    private void registrarEntrada() {
        String placa = campoPlaca.getValue().trim().toUpperCase();
        String tipo = selectTipo.getValue();
 
        // 1. Validar el formulario antes de tocar los archivos
        if (!placa.matches("[A-Z0-9]{5,7}")) {
            mostrarError("La placa debe tener entre 5 y 7 letras o números.");
            return;
        }
        if (tipo == null) {
            mostrarError("Elige el tipo de vehículo.");
            return;
        }
 
        List<Puesto> puestos = ArchivoParqueadero.leerPuestos();
        List<Registro> registros = ArchivoParqueadero.leerRegistros();
 
        // 2. La misma placa no puede estar adentro dos veces
        for (Registro registro : registros) {
            if (registro.estaAdentro() && registro.getPlaca().equals(placa)) {
                mostrarError("La placa " + placa + " ya está dentro del parqueadero.");
                return;
            }
        }
 
        // 3. Buscar el primer puesto libre del tipo de vehículo
        Puesto puestoLibre = null;
        for (Puesto puesto : puestos) {
            if (puesto.getTipo().equals(tipo) && puesto.estaLibre(registros)) {
                puestoLibre = puesto;
                break;
            }
        }
        if (puestoLibre == null) {
            mostrarError("No hay puestos libres para " + tipo + ".");
            return;
        }
 
        // 4. Guardar la entrada
        LocalDateTime ahora = LocalDateTime.now().withNano(0);
        registros.add(new Registro(placa, tipo, puestoLibre.getFila(), puestoLibre.getColumna(), ahora, null));
 
        if (!ArchivoParqueadero.guardarRegistros(registros)) {
            mostrarError("No se pudo guardar la entrada. Intenta de nuevo.");
            return;
        }
 
        mostrarExito("Entrada registrada: " + placa + " en la fila " + puestoLibre.getFila()
                + ", columna " + puestoLibre.getColumna() + ".");
        campoPlaca.clear();
        selectTipo.clear();
    }
 
    private void mostrarError(String mensaje) {
        Notification notificacion = Notification.show(mensaje, 4000, Notification.Position.MIDDLE);
        notificacion.addThemeVariants(NotificationVariant.LUMO_ERROR);
    }
 
    private void mostrarExito(String mensaje) {
        Notification notificacion = Notification.show(mensaje, 4000, Notification.Position.MIDDLE);
        notificacion.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
    }
}
 