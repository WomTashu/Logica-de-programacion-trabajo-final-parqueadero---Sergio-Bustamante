package com.example.parqueadero;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import java.time.LocalDateTime;
import java.util.List;

@PageTitle("Registrar entrada")
@Route(value = "entrada", layout = MainLayout.class)
public class EntradaView extends VerticalLayout {

    private final TextField campoPlaca = Utilidades.crearCampoPlaca();
    private final Select<String> selectTipo = new Select<>();

    public EntradaView() {
        selectTipo.setLabel("Tipo de vehículo");
        selectTipo.setItems("CARRO", "MOTO");

        Button botonRegistrar = new Button("Registrar entrada", evento -> registrarEntrada());
        botonRegistrar.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

        setMaxWidth("28rem");
        add(new H2("Registrar entrada"), campoPlaca, selectTipo, botonRegistrar);
    }

    private void registrarEntrada() {
        String placa = campoPlaca.getValue().trim().toUpperCase();
        String tipo = selectTipo.getValue();

        // 1. Validar el formulario antes de tocar los archivos
        if (!Utilidades.esPlacaValida(placa)) {
            Utilidades.mostrarError("La placa debe tener entre 5 y 7 letras o números.");
            return;
        }
        if (tipo == null) {
            Utilidades.mostrarError("Elige el tipo de vehículo.");
            return;
        }

        List<Puesto> puestos = ArchivoParqueadero.leerPuestos();
        List<Registro> registros = ArchivoParqueadero.leerRegistros();

        // 2. La misma placa no puede estar adentro dos veces
        if (Registro.buscarActivoPorPlaca(registros, placa) != null) {
            Utilidades.mostrarError("La placa " + placa + " ya está dentro del parqueadero.");
            return;
        }

        // 3. Buscar el primer puesto libre del tipo de vehículo
        Puesto puestoLibre = null;
        for (Puesto puesto : puestos) {
            if (puesto.getTipo().equals(tipo) && puesto.estaLibre(registros)) {
                puestoLibre = puesto;
                break;
            }
        }
        if (puestoLibre == null) {
            Utilidades.mostrarError("No hay puestos libres para " + tipo + ".");
            return;
        }

        // 4. Guardar la entrada
        LocalDateTime ahora = LocalDateTime.now().withNano(0);
        registros.add(new Registro(placa, tipo, puestoLibre.getFila(), puestoLibre.getColumna(), ahora, null));

        if (!ArchivoParqueadero.guardarRegistros(registros)) {
            Utilidades.mostrarError("No se pudo guardar la entrada. Intenta de nuevo.");
            return;
        }

        Utilidades.mostrarExito("Entrada registrada: " + placa + " en la fila " + puestoLibre.getFila()
                + ", columna " + puestoLibre.getColumna() + ".");
        campoPlaca.clear();
        selectTipo.clear();
    }
}