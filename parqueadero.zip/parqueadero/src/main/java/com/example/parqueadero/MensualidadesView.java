package com.example.parqueadero;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@PageTitle("Mensualidades")
@Route(value = "mensualidades", layout = MainLayout.class)
public class MensualidadesView extends VerticalLayout {

    private final Grid<Mensualidad> grid = new Grid<>();
    private final TextField campoBusqueda = new TextField();
    private final Select<String> filtroEstado = new Select<>();

    private List<Mensualidad> mensualidades = new ArrayList<>();

    public MensualidadesView() {
        campoBusqueda.setPlaceholder("Buscar por placa o titular");
        campoBusqueda.setClearButtonVisible(true);
        campoBusqueda.setValueChangeMode(ValueChangeMode.EAGER); // busca mientras escribes
        campoBusqueda.addValueChangeListener(evento -> actualizarGrid());

        filtroEstado.setItems("Todas", "Vigentes", "No vigentes");
        filtroEstado.setValue("Todas");
        filtroEstado.addValueChangeListener(evento -> actualizarGrid());

        Button botonNueva = new Button("Nueva mensualidad", evento -> abrirFormulario(null));
        botonNueva.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

        HorizontalLayout barra = new HorizontalLayout(campoBusqueda, filtroEstado, botonNueva);
        barra.getStyle().set("flex-wrap", "wrap"); // en el celular los controles bajan de línea

        grid.addColumn(Mensualidad::getPlaca).setHeader("Placa");
        grid.addColumn(Mensualidad::getTitular).setHeader("Titular");
        grid.addColumn(m -> m.getFechaInicio().format(Utilidades.FORMATO_FECHA)).setHeader("Inicio");
        grid.addColumn(m -> m.getFechaFin().format(Utilidades.FORMATO_FECHA)).setHeader("Fin");
        grid.addColumn(m -> m.estaVigente(LocalDate.now()) ? "Vigente" : "No vigente").setHeader("Estado");
        grid.addComponentColumn(this::crearBotonesDeAccion).setHeader("Acciones");
        grid.setWidthFull();

        add(new H2("Mensualidades"), barra, grid);
    }

    @Override
    protected void onAttach(AttachEvent evento) {
        cargarDatos();
    }

    private void cargarDatos() {
        mensualidades = ArchivoParqueadero.leerMensualidades();
        actualizarGrid();
    }

    // Muestra solo las mensualidades que cumplen la búsqueda y el filtro de estado
    private void actualizarGrid() {
        String texto = campoBusqueda.getValue().trim().toLowerCase();
        String estado = filtroEstado.getValue();
        LocalDate hoy = LocalDate.now();

        List<Mensualidad> visibles = new ArrayList<>();
        for (Mensualidad mensualidad : mensualidades) {
            boolean coincideTexto = mensualidad.getPlaca().toLowerCase().contains(texto)
                    || mensualidad.getTitular().toLowerCase().contains(texto);
            boolean vigente = mensualidad.estaVigente(hoy);
            boolean coincideEstado = "Todas".equals(estado)
                    || ("Vigentes".equals(estado) && vigente)
                    || ("No vigentes".equals(estado) && !vigente);

            if (coincideTexto && coincideEstado) {
                visibles.add(mensualidad);
            }
        }
        grid.setItems(visibles);
    }

    private HorizontalLayout crearBotonesDeAccion(Mensualidad mensualidad) {
        Button editar = new Button("Editar", evento -> abrirFormulario(mensualidad));
        editar.addThemeVariants(ButtonVariant.LUMO_SMALL);

        Button eliminar = new Button("Eliminar", evento -> confirmarEliminacion(mensualidad));
        eliminar.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_ERROR);

        return new HorizontalLayout(editar, eliminar);
    }

    // existente == null significa "crear una nueva"; si no, se edita esa mensualidad
    private void abrirFormulario(Mensualidad existente) {
        boolean esNueva = existente == null;

        Dialog dialogo = new Dialog();
        dialogo.setHeaderTitle(esNueva ? "Nueva mensualidad" : "Editar mensualidad");

        TextField campoPlaca = Utilidades.crearCampoPlaca();
        TextField campoTitular = new TextField("Titular");
        campoTitular.setMaxLength(40);
        DatePicker campoInicio = new DatePicker("Inicio");
        DatePicker campoFin = new DatePicker("Fin");

        if (esNueva) {
            campoInicio.setValue(LocalDate.now());
            campoFin.setValue(LocalDate.now().plusMonths(1));
        } else {
            campoPlaca.setValue(existente.getPlaca());
            campoPlaca.setReadOnly(true); // la placa identifica la mensualidad: no se cambia
            campoTitular.setValue(existente.getTitular());
            campoInicio.setValue(existente.getFechaInicio());
            campoFin.setValue(existente.getFechaFin());
        }

        Button guardar = new Button("Guardar", evento -> {
            boolean guardado = guardarMensualidad(existente, campoPlaca.getValue(),
                    campoTitular.getValue(), campoInicio.getValue(), campoFin.getValue());
            if (guardado) {
                dialogo.close();
            }
        });
        guardar.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        Button cancelar = new Button("Cancelar", evento -> dialogo.close());

        dialogo.add(new VerticalLayout(campoPlaca, campoTitular, campoInicio, campoFin));
        dialogo.getFooter().add(cancelar, guardar);
        dialogo.open();
    }

    // Valida, crea o modifica, y guarda. Devuelve true si todo salió bien
    private boolean guardarMensualidad(Mensualidad existente, String placaEscrita, String titularEscrito,
                                       LocalDate inicio, LocalDate fin) {
        String placa = placaEscrita.trim().toUpperCase();
        String titular = titularEscrito.trim();

        if (!Utilidades.esPlacaValida(placa)) {
            Utilidades.mostrarError("La placa debe tener entre 5 y 7 letras o números.");
            return false;
        }
        if (titular.isEmpty()) {
            Utilidades.mostrarError("Escribe el nombre del titular.");
            return false;
        }
        if (titular.contains("|")) { // el | separa los campos del archivo: no puede ir dentro de un dato
            Utilidades.mostrarError("El titular no puede contener el carácter |.");
            return false;
        }
        if (inicio == null || fin == null) {
            Utilidades.mostrarError("Elige la fecha de inicio y la de fin.");
            return false;
        }
        if (fin.isBefore(inicio)) {
            Utilidades.mostrarError("La fecha de fin no puede ser anterior a la de inicio.");
            return false;
        }

        if (existente == null) {
            for (Mensualidad mensualidad : mensualidades) {
                if (mensualidad.getPlaca().equals(placa)) {
                    Utilidades.mostrarError("Ya existe una mensualidad para la placa " + placa + ". Edítala.");
                    return false;
                }
            }
            mensualidades.add(new Mensualidad(placa, titular, inicio, fin));
        } else {
            existente.setTitular(titular);
            existente.setFechaInicio(inicio);
            existente.setFechaFin(fin);
        }

        if (!guardarCambios()) {
            return false;
        }
        Utilidades.mostrarExito("Mensualidad guardada.");
        return true;
    }

    private void confirmarEliminacion(Mensualidad mensualidad) {
        Dialog dialogo = new Dialog();
        dialogo.setHeaderTitle("Eliminar mensualidad");
        dialogo.add(new Span("¿Eliminar la mensualidad de la placa " + mensualidad.getPlaca()
                + "? Esta acción no se puede deshacer."));

        Button eliminar = new Button("Eliminar", evento -> {
            mensualidades.remove(mensualidad);
            if (guardarCambios()) {
                Utilidades.mostrarExito("Mensualidad eliminada.");
            }
            dialogo.close();
        });
        eliminar.addThemeVariants(ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_ERROR);
        Button cancelar = new Button("Cancelar", evento -> dialogo.close());

        dialogo.getFooter().add(cancelar, eliminar);
        dialogo.open();
    }

    // Si no se puede guardar, se recarga el archivo para que la pantalla no muestre algo que no quedó guardado
    private boolean guardarCambios() {
        if (ArchivoParqueadero.guardarMensualidades(mensualidades)) {
            actualizarGrid();
            return true;
        }
        Utilidades.mostrarError("No se pudo guardar. Se recargaron los datos del archivo.");
        cargarDatos();
        return false;
    }
}