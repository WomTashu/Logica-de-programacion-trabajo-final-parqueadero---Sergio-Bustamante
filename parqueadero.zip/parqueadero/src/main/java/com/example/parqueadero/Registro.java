package com.example.parqueadero;

import java.time.LocalDateTime;
 
public class Registro {
 
    private final String placa;
    private final String tipo;
    private final int fila;
    private final int columna;
    private final LocalDateTime horaEntrada;
    private final LocalDateTime horaSalida; // null mientras el vehículo siga dentro
 
    public Registro(String placa, String tipo, int fila, int columna,
                    LocalDateTime horaEntrada, LocalDateTime horaSalida) {
        this.placa = placa;
        this.tipo = tipo;
        this.fila = fila;
        this.columna = columna;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
    }
 
    public String getPlaca() {
        return placa;
    }
 
    public String getTipo() {
        return tipo;
    }
 
    public int getFila() {
        return fila;
    }
 
    public int getColumna() {
        return columna;
    }
 
    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }
 
    public boolean estaAdentro() {
        return horaSalida == null;
    }
 
    // Convierte el registro en una línea de texto con los campos separados por |
    public String aLinea() {
        String salida = (horaSalida == null) ? "" : horaSalida.toString();
        return placa + "|" + tipo + "|" + fila + "|" + columna + "|" + horaEntrada + "|" + salida;
    }
}
 