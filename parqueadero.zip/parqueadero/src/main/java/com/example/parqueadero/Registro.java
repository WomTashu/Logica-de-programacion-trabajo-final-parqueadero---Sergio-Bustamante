package com.example.parqueadero;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

public class Registro {

    private final String placa;
    private final String tipo;
    private final int fila;
    private final int columna;
    private final LocalDateTime horaEntrada;
    private LocalDateTime horaSalida; // null mientras el vehículo siga dentro
    private int valorCobrado;         // 0 mientras siga dentro o si tenía mensualidad

    public Registro(String placa, String tipo, int fila, int columna,
                    LocalDateTime horaEntrada, LocalDateTime horaSalida, int valorCobrado) {
        this.placa = placa;
        this.tipo = tipo;
        this.fila = fila;
        this.columna = columna;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.valorCobrado = valorCobrado;
    }

    // Constructor corto para una entrada nueva: todavía no hay salida ni cobro
    public Registro(String placa, String tipo, int fila, int columna,
                    LocalDateTime horaEntrada, LocalDateTime horaSalida) {
        this(placa, tipo, fila, columna, horaEntrada, horaSalida, 0);
    }

    public String getPlaca() {
        return placa;
    }

    public String getTipo() {
        return tipo;
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }

    public LocalDateTime getHoraSalida() {
        return horaSalida;
    }

    public int getValorCobrado() {
        return valorCobrado;
    }

    public boolean estaAdentro() {
        return horaSalida == null;
    }

    public void registrarSalida(LocalDateTime hora, int valor) {
        this.horaSalida = hora;
        this.valorCobrado = valor;
    }

    // Horas a cobrar hasta el momento "hasta": la fracción de hora cuenta como hora completa
    public int horasACobrar(LocalDateTime hasta) {
        long segundos = Duration.between(horaEntrada, hasta).getSeconds();
        long horas = (segundos + 3599) / 3600; // división hacia arriba
        return (int) Math.max(horas, 1);       // mínimo 1 hora
    }

    public String tiempoTranscurrido(LocalDateTime hasta) {
        Duration duracion = Duration.between(horaEntrada, hasta);
        return duracion.toHours() + " h " + duracion.toMinutesPart() + " min";
    }

    // Devuelve el registro de esa placa que siga dentro del parqueadero, o null si no hay
    public static Registro buscarActivoPorPlaca(List<Registro> registros, String placa) {
        for (Registro registro : registros) {
            if (registro.estaAdentro() && registro.getPlaca().equals(placa)) {
                return registro;
            }
        }
        return null;
    }

    // Convierte el registro en una línea de texto con los campos separados por |
    public String aLinea() {
        String salida = (horaSalida == null) ? "" : horaSalida.toString();
        return placa + "|" + tipo + "|" + fila + "|" + columna + "|" + horaEntrada + "|" + salida + "|" + valorCobrado;
    }
}