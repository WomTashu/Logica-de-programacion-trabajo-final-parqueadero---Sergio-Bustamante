package com.example.parqueadero;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class Reportes {

    // Ingresos agrupados por la fecha de SALIDA (es cuando se cobra), del día más reciente al más antiguo
    public static List<IngresoDia> ingresosPorDia(List<Registro> registros) {
        List<IngresoDia> dias = new ArrayList<>();

        for (Registro registro : registros) {
            if (!registro.estaAdentro()) { // mientras siga dentro, todavía no ha pagado
                LocalDate fecha = registro.getHoraSalida().toLocalDate();
                IngresoDia dia = buscarDia(dias, fecha);
                if (dia == null) {
                    dia = new IngresoDia(fecha);
                    dias.add(dia);
                }
                dia.agregarSalida(registro.getValorCobrado());
            }
        }

        dias.sort((a, b) -> b.getFecha().compareTo(a.getFecha()));
        return dias;
    }

    private static IngresoDia buscarDia(List<IngresoDia> dias, LocalDate fecha) {
        for (IngresoDia dia : dias) {
            if (dia.getFecha().equals(fecha)) {
                return dia;
            }
        }
        return null;
    }

    // Devuelve 24 valores: para cada hora del día (0 a 23), el promedio de puestos ocupados
    // durante los últimos 7 días.
    public static double[] ocupacionPorHora(List<Registro> registros, LocalDateTime ahora) {
        double[] suma = new double[24];

        // Tomo las últimas 168 horas completas (7 días x 24 h) que ya terminaron. En 168 horas
        // seguidas, cada hora del día aparece exactamente 7 veces, así que al final basta dividir entre 7.
        LocalDateTime finUltimaHora = ahora.truncatedTo(ChronoUnit.HOURS);
        for (int k = 0; k < 168; k++) {
            LocalDateTime fin = finUltimaHora.minusHours(k);
            LocalDateTime inicio = fin.minusHours(1);
            suma[inicio.getHour()] += puestosOcupadosEn(registros, inicio, fin, ahora);
        }

        double[] promedio = new double[24];
        for (int hora = 0; hora < 24; hora++) {
            promedio[hora] = suma[hora] / 7;
        }
        return promedio;
    }

    // Promedio de puestos ocupados entre inicio y fin (una hora). Cada vehículo aporta el tiempo que
    // estuvo dentro de esa hora. Como la hora dura 3600 segundos, sumar los segundos de todos los
    // vehículos y dividir entre 3600 da el promedio de puestos ocupados durante esa hora.
    private static double puestosOcupadosEn(List<Registro> registros, LocalDateTime inicio,
                                            LocalDateTime fin, LocalDateTime ahora) {
        double segundos = 0;

        for (Registro registro : registros) {
            LocalDateTime entrada = registro.getHoraEntrada();
            LocalDateTime salida = registro.estaAdentro() ? ahora : registro.getHoraSalida();

            // El tramo que se cuenta es la parte de la visita que cae dentro de la hora
            LocalDateTime desde = entrada.isAfter(inicio) ? entrada : inicio;
            LocalDateTime hasta = salida.isBefore(fin) ? salida : fin;

            if (hasta.isAfter(desde)) {
                segundos += Duration.between(desde, hasta).getSeconds();
            }
        }
        return segundos / 3600;
    }

    public static double maximo(double[] valores) {
        double maximo = 0;
        for (double valor : valores) {
            maximo = Math.max(maximo, valor);
        }
        return maximo;
    }

    // Las horas pico son las de mayor promedio (puede haber empate). Si no hubo ocupación, no hay pico.
    public static List<Integer> horasPico(double[] promedios) {
        double maximo = maximo(promedios);
        List<Integer> horas = new ArrayList<>();

        if (maximo > 0) {
            for (int hora = 0; hora < 24; hora++) {
                if (promedios[hora] >= maximo - 0.000001) { // pequeña tolerancia por decimales
                    horas.add(hora);
                }
            }
        }
        return horas;
    }
}