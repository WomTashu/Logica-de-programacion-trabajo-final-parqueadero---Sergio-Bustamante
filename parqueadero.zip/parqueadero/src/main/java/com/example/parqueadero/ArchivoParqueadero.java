package com.example.parqueadero;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class ArchivoParqueadero {

    private static final Path CARPETA = Path.of("datos");
    private static final Path ARCHIVO_PUESTOS = CARPETA.resolve("puestos.txt");
    private static final Path ARCHIVO_REGISTROS = CARPETA.resolve("registros.txt");
    private static final Path ARCHIVO_MENSUALIDADES = CARPETA.resolve("mensualidades.txt");

    public static List<Puesto> leerPuestos() {
        List<Puesto> puestos = new ArrayList<>();
        try {
            crearDatosDeEjemploSiFaltan();
            for (String linea : Files.readAllLines(ARCHIVO_PUESTOS)) {
                try {
                    String[] partes = linea.split("\\|");
                    int fila = Integer.parseInt(partes[0]);
                    int columna = Integer.parseInt(partes[1]);
                    puestos.add(new Puesto(fila, columna, partes[2]));
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Línea ignorada en puestos.txt: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer puestos.txt: " + e.getMessage());
        }
        return puestos;
    }

    public static List<Registro> leerRegistros() {
        List<Registro> registros = new ArrayList<>();
        try {
            crearDatosDeEjemploSiFaltan();
            for (String linea : Files.readAllLines(ARCHIVO_REGISTROS)) {
                try {
                    String[] partes = linea.split("\\|", -1); // -1 conserva los campos vacíos del final
                    LocalDateTime horaEntrada = LocalDateTime.parse(partes[4]);
                    LocalDateTime horaSalida = partes[5].isBlank() ? null : LocalDateTime.parse(partes[5]);
                    // El séptimo campo (valor cobrado) puede faltar en archivos antiguos: se toma 0
                    int valorCobrado = (partes.length > 6 && !partes[6].isBlank()) ? Integer.parseInt(partes[6]) : 0;
                    registros.add(new Registro(partes[0], partes[1],
                            Integer.parseInt(partes[2]), Integer.parseInt(partes[3]),
                            horaEntrada, horaSalida, valorCobrado));
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException | DateTimeParseException e) {
                    System.out.println("Línea ignorada en registros.txt: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer registros.txt: " + e.getMessage());
        }
        return registros;
    }

    public static List<Mensualidad> leerMensualidades() {
        List<Mensualidad> mensualidades = new ArrayList<>();
        try {
            crearDatosDeEjemploSiFaltan();
            for (String linea : Files.readAllLines(ARCHIVO_MENSUALIDADES)) {
                try {
                    String[] partes = linea.split("\\|");
                    mensualidades.add(new Mensualidad(partes[0], partes[1],
                            LocalDate.parse(partes[2]), LocalDate.parse(partes[3])));
                } catch (ArrayIndexOutOfBoundsException | DateTimeParseException e) {
                    System.out.println("Línea ignorada en mensualidades.txt: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer mensualidades.txt: " + e.getMessage());
        }
        return mensualidades;
    }

    // Reescribe registros.txt completo con la lista recibida. Devuelve false si no pudo guardar.
    public static boolean guardarRegistros(List<Registro> registros) {
        try {
            List<String> lineas = new ArrayList<>();
            for (Registro registro : registros) {
                lineas.add(registro.aLinea());
            }
            Files.write(ARCHIVO_REGISTROS, lineas);
            return true;
        } catch (IOException e) {
            System.out.println("No se pudo guardar registros.txt: " + e.getMessage());
            return false;
        }
    }

    public static boolean guardarMensualidades(List<Mensualidad> mensualidades) {
        try {
            List<String> lineas = new ArrayList<>();
            for (Mensualidad mensualidad : mensualidades) {
                lineas.add(mensualidad.aLinea());
            }
            Files.write(ARCHIVO_MENSUALIDADES, lineas);
            return true;
        } catch (IOException e) {
            System.out.println("No se pudo guardar mensualidades.txt: " + e.getMessage());
            return false;
        }
    }

    // Cada archivo se revisa por separado: solo se crea el que falte, y nunca se pisa uno existente
    private static void crearDatosDeEjemploSiFaltan() throws IOException {
        Files.createDirectories(CARPETA);

        if (!Files.exists(ARCHIVO_PUESTOS)) {
            List<String> lineas = new ArrayList<>();
            for (int fila = 1; fila <= 4; fila++) {
                for (int columna = 1; columna <= 6; columna++) {
                    String tipo = (fila <= 3) ? "CARRO" : "MOTO";
                    lineas.add(fila + "|" + columna + "|" + tipo);
                }
            }
            Files.write(ARCHIVO_PUESTOS, lineas);
        }

        if (!Files.exists(ARCHIVO_REGISTROS)) {
            List<String> lineas = new ArrayList<>();
            agregarHistorialDeEjemplo(lineas); // primero lo más antiguo: el archivo queda en orden cronológico

            LocalDateTime ahora = LocalDateTime.now().withNano(0);
            lineas.add("ABC123|CARRO|1|1|" + ahora.minusHours(2) + "||0");
            lineas.add("XYZ98A|MOTO|4|1|" + ahora.minusMinutes(45) + "||0");
            Files.write(ARCHIVO_REGISTROS, lineas);
        }

        if (!Files.exists(ARCHIVO_MENSUALIDADES)) {
            LocalDate hoy = LocalDate.now();
            List<String> lineas = List.of(
                    "ABC123|Carlos Ramírez|" + hoy.minusDays(10) + "|" + hoy.plusDays(20),
                    "MEN456|Laura Gómez|" + hoy.minusDays(60) + "|" + hoy.minusDays(30));
            Files.write(ARCHIVO_MENSUALIDADES, lineas);
        }
    }

    // Crea visitas ya terminadas de los últimos 7 días, para que el historial y los reportes tengan datos
    private static void agregarHistorialDeEjemplo(List<String> lineas) {
        int[] horasEntrada = {7, 8, 8, 9, 12, 13, 17, 18, 18, 19};
        int[] minutosDeEstadia = {90, 45, 200, 30, 120, 60, 150, 240, 75, 20};

        for (int diasAtras = 7; diasAtras >= 1; diasAtras--) {
            for (int v = 0; v < horasEntrada.length; v++) {
                String tipo = (v % 3 == 0) ? "MOTO" : "CARRO";
                LocalDateTime entrada = LocalDate.now().minusDays(diasAtras).atTime(horasEntrada[v], v * 5);
                LocalDateTime salida = entrada.plusMinutes(minutosDeEstadia[v] + diasAtras * 3);
                lineas.add(crearLineaDeVisitaTerminada("HI" + diasAtras + "V" + v, tipo, entrada, salida));
            }

            // Una visita que pasa la noche: entra a las 22:10 y sale al día siguiente a las 06:40
            if (diasAtras == 2) {
                LocalDateTime entrada = LocalDate.now().minusDays(2).atTime(22, 10);
                LocalDateTime salida = LocalDate.now().minusDays(1).atTime(6, 40);
                lineas.add(crearLineaDeVisitaTerminada("NOCHE1", "CARRO", entrada, salida));
            }
        }
    }

    // Arma la línea de una visita terminada, con el valor que cobraría la tarifa actual
    private static String crearLineaDeVisitaTerminada(String placa, String tipo,
                                                      LocalDateTime entrada, LocalDateTime salida) {
        int fila = tipo.equals("MOTO") ? 4 : 1;
        Registro registro = new Registro(placa, tipo, fila, 2, entrada, null);
        registro.registrarSalida(salida, Tarifa.calcularValor(registro, salida));
        return registro.aLinea();
    }
}