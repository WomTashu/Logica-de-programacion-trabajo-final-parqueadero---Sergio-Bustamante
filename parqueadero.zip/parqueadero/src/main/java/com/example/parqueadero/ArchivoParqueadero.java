package com.example.parqueadero;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class ArchivoParqueadero {

    private static final Path CARPETA = Path.of("datos");
    private static final Path ARCHIVO_PUESTOS = CARPETA.resolve("puestos.txt");
    private static final Path ARCHIVO_REGISTROS = CARPETA.resolve("registros.txt");
    private static final Path ARCHIVO_MENSUALIDADES = CARPETA.resolve("mensualidades.txt");

    public static List<Puesto> leerPuestos() {
        List<Puesto> puestos = new ArrayList<>();
        try {
            crearDatosDeEjemploSiFaltan();
            for (String linea : Files.readAllLines(ARCHIVO_PUESTOS)) {
                try {
                    String[] partes = linea.split("\\|");
                    int fila = Integer.parseInt(partes[0]);
                    int columna = Integer.parseInt(partes[1]);
                    puestos.add(new Puesto(fila, columna, partes[2]));
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Línea ignorada en puestos.txt: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer puestos.txt: " + e.getMessage());
        }
        return puestos;
    }

    public static List<Registro> leerRegistros() {
        List<Registro> registros = new ArrayList<>();
        try {
            crearDatosDeEjemploSiFaltan();
            for (String linea : Files.readAllLines(ARCHIVO_REGISTROS)) {
                try {
                    String[] partes = linea.split("\\|", -1); // -1 conserva los campos vacíos del final
                    LocalDateTime horaEntrada = LocalDateTime.parse(partes[4]);
                    LocalDateTime horaSalida = partes[5].isBlank() ? null : LocalDateTime.parse(partes[5]);
                    // El séptimo campo (valor cobrado) puede faltar en archivos antiguos: se toma 0
                    int valorCobrado = (partes.length > 6 && !partes[6].isBlank()) ? Integer.parseInt(partes[6]) : 0;
                    registros.add(new Registro(partes[0], partes[1],
                            Integer.parseInt(partes[2]), Integer.parseInt(partes[3]),
                            horaEntrada, horaSalida, valorCobrado));
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException | DateTimeParseException e) {
                    System.out.println("Línea ignorada en registros.txt: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer registros.txt: " + e.getMessage());
        }
        return registros;
    }

    public static List<Mensualidad> leerMensualidades() {
        List<Mensualidad> mensualidades = new ArrayList<>();
        try {
            crearDatosDeEjemploSiFaltan();
            for (String linea : Files.readAllLines(ARCHIVO_MENSUALIDADES)) {
                try {
                    String[] partes = linea.split("\\|");
                    mensualidades.add(new Mensualidad(partes[0], partes[1],
                            LocalDate.parse(partes[2]), LocalDate.parse(partes[3])));
                } catch (ArrayIndexOutOfBoundsException | DateTimeParseException e) {
                    System.out.println("Línea ignorada en mensualidades.txt: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer mensualidades.txt: " + e.getMessage());
        }
        return mensualidades;
    }

    // Reescribe registros.txt completo con la lista recibida. Devuelve false si no pudo guardar.
    public static boolean guardarRegistros(List<Registro> registros) {
        try {
            List<String> lineas = new ArrayList<>();
            for (Registro registro : registros) {
                lineas.add(registro.aLinea());
            }
            Files.write(ARCHIVO_REGISTROS, lineas);
            return true;
        } catch (IOException e) {
            System.out.println("No se pudo guardar registros.txt: " + e.getMessage());
            return false;
        }
    }

    public static boolean guardarMensualidades(List<Mensualidad> mensualidades) {
        try {
            List<String> lineas = new ArrayList<>();
            for (Mensualidad mensualidad : mensualidades) {
                lineas.add(mensualidad.aLinea());
            }
            Files.write(ARCHIVO_MENSUALIDADES, lineas);
            return true;
        } catch (IOException e) {
            System.out.println("No se pudo guardar mensualidades.txt: " + e.getMessage());
            return false;
        }
    }

    // Cada archivo se revisa por separado: solo se crea el que falte, y nunca se pisa uno existente
    private static void crearDatosDeEjemploSiFaltan() throws IOException {
        Files.createDirectories(CARPETA);

        if (!Files.exists(ARCHIVO_PUESTOS)) {
            List<String> lineas = new ArrayList<>();
            for (int fila = 1; fila <= 4; fila++) {
                for (int columna = 1; columna <= 6; columna++) {
                    String tipo = (fila <= 3) ? "CARRO" : "MOTO";
                    lineas.add(fila + "|" + columna + "|" + tipo);
                }
            }
            Files.write(ARCHIVO_PUESTOS, lineas);
        }

        if (!Files.exists(ARCHIVO_REGISTROS)) {
            LocalDateTime ahora = LocalDateTime.now().withNano(0);
            List<String> lineas = List.of(
                    "ABC123|CARRO|1|1|" + ahora.minusHours(2) + "||0",
                    "XYZ98A|MOTO|4|1|" + ahora.minusMinutes(45) + "||0");
            Files.write(ARCHIVO_REGISTROS, lineas);
        }

        if (!Files.exists(ARCHIVO_MENSUALIDADES)) {
            LocalDate hoy = LocalDate.now();
            List<String> lineas = List.of(
                    "ABC123|Carlos Ramírez|" + hoy.minusDays(10) + "|" + hoy.plusDays(20),
                    "MEN456|Laura Gómez|" + hoy.minusDays(60) + "|" + hoy.minusDays(30));
            Files.write(ARCHIVO_MENSUALIDADES, lineas);
        }
    }
}