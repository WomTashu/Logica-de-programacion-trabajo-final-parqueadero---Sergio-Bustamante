package com.example.parqueadero;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datetimepicker.DateTimePicker;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@PageTitle("Historial")
@Route(value = "historial", layout = MainLayout.class)
public class HistorialView extends VerticalLayout {

    private final Grid<Registro> grid = new Grid<>();
    private final TextField campoBusqueda = new TextField();
    private final Select<String> filtroEstado = new Select<>();
    private final DateTimePicker campoDesde = new DateTimePicker();
    private final DateTimePicker campoHasta = new DateTimePicker();
    private final Span resumen = new Span();

    private List<Registro> registros = new ArrayList<>();

    public HistorialView() {
        campoBusqueda.setPlaceholder("Buscar por placa");
        campoBusqueda.setClearButtonVisible(true);
        campoBusqueda.setValueChangeMode(ValueChangeMode.EAGER); // busca mientras escribes
        campoBusqueda.addValueChangeListener(evento -> actualizarGrid());

        filtroEstado.setLabel("Estado");
        filtroEstado.setItems("Todos", "Dentro", "Ya salieron");
        filtroEstado.setValue("Todos");
        filtroEstado.addValueChangeListener(evento -> actualizarGrid());

        campoDesde.setLabel("Entró desde");
        campoDesde.addValueChangeListener(evento -> actualizarGrid());
        campoHasta.setLabel("Entró hasta");
        campoHasta.addValueChangeListener(evento -> actualizarGrid());

        Button botonLimpiar = new Button("Limpiar filtros", evento -> limpiarFiltros());

        HorizontalLayout filtros = new HorizontalLayout(campoBusqueda, filtroEstado, campoDesde, campoHasta, botonLimpiar);
        filtros.setAlignItems(FlexComponent.Alignment.END);
        filtros.getStyle().set("flex-wrap", "wrap"); // en el celular los controles bajan de línea

        grid.addColumn(Registro::getPlaca).setHeader("Placa");
        grid.addColumn(Registro::getTipo).setHeader("Tipo");
        grid.addColumn(r -> r.getFila() + "-" + r.getColumna()).setHeader("Puesto (fila-col)");
        grid.addColumn(r -> r.getHoraEntrada().format(Utilidades.FORMATO_FECHA_HORA)).setHeader("Entrada");
        grid.addColumn(r -> r.estaAdentro() ? "Dentro" : r.getHoraSalida().format(Utilidades.FORMATO_FECHA_HORA))
                .setHeader("Salida");
        grid.addColumn(r -> r.tiempoTranscurrido(r.estaAdentro() ? LocalDateTime.now() : r.getHoraSalida()))
                .setHeader("Tiempo");
        grid.addColumn(r -> r.estaAdentro() ? "-" : Utilidades.formatearDinero(r.getValorCobrado()))
                .setHeader("Cobrado");
        grid.setWidthFull();

        resumen.getStyle().set("font-weight", "bold");

        add(new H2("Historial de entradas y salidas"), filtros, resumen, grid);
    }

    @Override
    protected void onAttach(AttachEvent evento) {
        registros = ArchivoParqueadero.leerRegistros();
        actualizarGrid();
    }

    private void limpiarFiltros() {
        campoBusqueda.clear();
        filtroEstado.setValue("Todos");
        campoDesde.clear();
        campoHasta.clear();
    }

    // Muestra solo los registros que cumplen la placa, el estado y el rango de fecha y hora
    private void actualizarGrid() {
        String texto = campoBusqueda.getValue().trim().toUpperCase(); // las placas se guardan en mayúscula
        String estado = filtroEstado.getValue();
        LocalDateTime desde = campoDesde.getValue(); // null si el campo está vacío
        LocalDateTime hasta = campoHasta.getValue();

        if (desde != null && hasta != null && hasta.isBefore(desde)) {
            grid.setItems(new ArrayList<>());
            resumen.setText("El rango no es válido: \"Entró hasta\" es anterior a \"Entró desde\".");
            return;
        }

        List<Registro> visibles = new ArrayList<>();
        int ingresos = 0;

        // Recorro de atrás hacia adelante: el archivo está en orden de llegada, así el más reciente sale primero
        for (int i = registros.size() - 1; i >= 0; i--) {
            Registro registro = registros.get(i);

            boolean coincidePlaca = registro.getPlaca().contains(texto);
            boolean coincideEstado = "Todos".equals(estado)
                    || ("Dentro".equals(estado) && registro.estaAdentro())
                    || ("Ya salieron".equals(estado) && !registro.estaAdentro());
            boolean despuesDeDesde = desde == null || !registro.getHoraEntrada().isBefore(desde);
            boolean antesDeHasta = hasta == null || !registro.getHoraEntrada().isAfter(hasta);

            if (coincidePlaca && coincideEstado && despuesDeDesde && antesDeHasta) {
                visibles.add(registro);
                ingresos += registro.getValorCobrado();
            }
        }

        grid.setItems(visibles);
        resumen.setText(visibles.size() + " registros. Ingresos de esta selección: "
                + Utilidades.formatearDinero(ingresos));
    }
}