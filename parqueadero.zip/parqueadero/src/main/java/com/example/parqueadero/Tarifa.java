package com.example.parqueadero;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Tarifa {

    // true  = cobro por minutos (bonificación).
    // false = cobro por hora, con la fracción de hora como hora completa (regla base del punto 3).
    public static final boolean COBRO_POR_MINUTOS = true;

    // Regla base: por hora
    public static final int CARRO_POR_HORA = 4000;
    public static final int MOTO_POR_HORA = 2000;

    // Bonificación: por minutos
    public static final int MINUTOS_GRATIS = 15;
    public static final int CARRO_POR_MINUTO = 70;
    public static final int MOTO_POR_MINUTO = 35;
    public static final int CARRO_TOPE_POR_DIA = 20000;
    public static final int MOTO_TOPE_POR_DIA = 10000;

    public static int porHora(String tipo) {
        return tipo.equals("CARRO") ? CARRO_POR_HORA : MOTO_POR_HORA;
    }

    public static int porMinuto(String tipo) {
        return tipo.equals("CARRO") ? CARRO_POR_MINUTO : MOTO_POR_MINUTO;
    }

    public static int topePorDia(String tipo) {
        return tipo.equals("CARRO") ? CARRO_TOPE_POR_DIA : MOTO_TOPE_POR_DIA;
    }

    // Es el único método que usan las demás clases para saber cuánto cobrar
    public static int calcularValor(Registro registro, LocalDateTime salida) {
        if (COBRO_POR_MINUTOS) {
            return calcularPorMinutos(registro.getTipo(), registro.getHoraEntrada(), salida);
        }
        return registro.horasACobrar(salida) * porHora(registro.getTipo());
    }

    private static int calcularPorMinutos(String tipo, LocalDateTime entrada, LocalDateTime salida) {
        // Se cuentan minutos completos: se descartan los segundos de la entrada y de la salida
        LocalDateTime desde = entrada.truncatedTo(ChronoUnit.MINUTES);
        LocalDateTime fin = salida.truncatedTo(ChronoUnit.MINUTES);

        long gratisPendientes = MINUTOS_GRATIS; // los minutos gratis se descuentan UNA vez por visita
        long total = 0;

        // Parto la estadía en "tramos" de un mismo día de calendario: si el vehículo pasa la noche,
        // el primer tramo termina a la medianoche y el siguiente empieza ahí. Así cada día se cobra
        // por separado y se le aplica su propio tope máximo.
        while (desde.isBefore(fin)) {
            LocalDateTime medianoche = desde.toLocalDate().plusDays(1).atStartOfDay();
            LocalDateTime hasta = medianoche.isBefore(fin) ? medianoche : fin;

            long minutosDelTramo = Duration.between(desde, hasta).toMinutes();
            long gratis = Math.min(gratisPendientes, minutosDelTramo);
            gratisPendientes -= gratis;
            long cobrables = minutosDelTramo - gratis;

            total += Math.min(cobrables * porMinuto(tipo), topePorDia(tipo));
            desde = hasta;
        }
        return (int) total;
    }
}