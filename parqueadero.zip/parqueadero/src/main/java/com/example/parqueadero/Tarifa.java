package com.example.parqueadero;

public class Tarifa {

    public static final int CARRO_POR_HORA = 4000;
    public static final int MOTO_POR_HORA = 2000;

    public static int porHora(String tipo) {
        return tipo.equals("CARRO") ? CARRO_POR_HORA : MOTO_POR_HORA;
    }
}