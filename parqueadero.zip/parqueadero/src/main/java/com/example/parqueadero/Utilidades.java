package com.example.parqueadero;

import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.textfield.TextField;

import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

// Cosas que necesitan varias vistas, para no repetir el mismo código en cada una
public class Utilidades {

    public static final DateTimeFormatter FORMATO_FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    public static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static TextField crearCampoPlaca() {
        TextField campo = new TextField("Placa");
        campo.setPlaceholder("ABC123");
        campo.setMaxLength(7);
        campo.setAllowedCharPattern("[A-Za-z0-9]");
        return campo;
    }

    // La placa debe llegar ya en mayúsculas y sin espacios
    public static boolean esPlacaValida(String placa) {
        return placa.matches("[A-Z0-9]{5,7}");
    }

    // 4000 -> "$4.000"
    public static String formatearDinero(int valor) {
        return "$" + NumberFormat.getIntegerInstance(Locale.of("es", "CO")).format(valor);
    }

    public static void mostrarError(String mensaje) {
        Notification notificacion = Notification.show(mensaje, 4000, Notification.Position.MIDDLE);
        notificacion.addThemeVariants(NotificationVariant.LUMO_ERROR);
    }

    public static void mostrarExito(String mensaje) {
        Notification notificacion = Notification.show(mensaje, 4000, Notification.Position.MIDDLE);
        notificacion.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
    }
}