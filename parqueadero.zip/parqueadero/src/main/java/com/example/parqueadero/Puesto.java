package com.example.parqueadero;

import java.util.List;

public class Puesto {

    private final int fila;
    private final int columna;
    private final String tipo; // "CARRO" o "MOTO"

    public Puesto(int fila, int columna, String tipo) {
        this.fila = fila;
        this.columna = columna;
        this.tipo = tipo;
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public String getTipo() {
        return tipo;
    }

    // Devuelve el registro del vehículo que está dentro de este puesto, o null si no hay nadie
    public Registro buscarRegistroActivo(List<Registro> registros) {
        for (Registro registro : registros) {
            boolean mismaPosicion = registro.getFila() == fila && registro.getColumna() == columna;
            if (registro.estaAdentro() && mismaPosicion) {
                return registro;
            }
        }
        return null;
    }

    public boolean estaLibre(List<Registro> registros) {
        return buscarRegistroActivo(registros) == null;
    }
}