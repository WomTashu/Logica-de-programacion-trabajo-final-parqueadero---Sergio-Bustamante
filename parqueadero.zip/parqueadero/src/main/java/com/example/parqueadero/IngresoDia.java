package com.example.parqueadero;

import java.time.LocalDate;

// Una fila del reporte de ingresos: lo que se cobró en un día
public class IngresoDia {

    private final LocalDate fecha;
    private int salidas;
    private int ingresos;

    public IngresoDia(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getSalidas() {
        return salidas;
    }

    public int getIngresos() {
        return ingresos;
    }

    public void agregarSalida(int valorCobrado) {
        salidas++;
        ingresos += valorCobrado;
    }
}