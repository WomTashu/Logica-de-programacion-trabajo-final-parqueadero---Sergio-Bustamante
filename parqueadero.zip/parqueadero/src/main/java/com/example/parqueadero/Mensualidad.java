package com.example.parqueadero;

import java.time.LocalDate;

public class Mensualidad {

    private final String placa; // no se edita: identifica la mensualidad
    private String titular;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;

    public Mensualidad(String placa, String titular, LocalDate fechaInicio, LocalDate fechaFin) {
        this.placa = placa;
        this.titular = titular;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public String getPlaca() {
        return placa;
    }

    public String getTitular() {
        return titular;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    // Vigente: la fecha cae entre el inicio y el fin, ambos días incluidos
    public boolean estaVigente(LocalDate fecha) {
        return !fecha.isBefore(fechaInicio) && !fecha.isAfter(fechaFin);
    }

    public String aLinea() {
        return placa + "|" + titular + "|" + fechaInicio + "|" + fechaFin;
    }
}