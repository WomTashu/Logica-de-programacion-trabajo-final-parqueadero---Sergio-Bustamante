package com.example.parqueadero;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.popover.Popover;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import java.time.LocalDateTime;
import java.util.List;

@PageTitle("Plano del parqueadero")
@Route(value = "", layout = MainLayout.class)
public class PlanoView extends VerticalLayout {

    private static final String COLOR_LIBRE = "#2e7d32";
    private static final String COLOR_OCUPADO = "#c62828";

    private final VerticalLayout plano = new VerticalLayout();

    public PlanoView() {
        plano.setPadding(false);
        plano.setSpacing(false);
        plano.getStyle().set("gap", "6px").set("overflow-x", "auto"); // si no cabe en el celular, se desliza

        add(new H2("Plano del parqueadero"), crearLeyenda(), plano);
    }

    // Se ejecuta cada vez que entras a esta vista, así el plano siempre muestra datos actuales
    @Override
    protected void onAttach(AttachEvent evento) {
        dibujarPlano();
    }

    private void dibujarPlano() {
        plano.removeAll();

        List<Puesto> puestos = ArchivoParqueadero.leerPuestos();
        List<Registro> registros = ArchivoParqueadero.leerRegistros();

        if (puestos.isEmpty()) {
            plano.add(new Span("No hay puestos para mostrar."));
            return;
        }

        HorizontalLayout filaActual = null;
        int numeroFilaActual = -1;

        for (Puesto puesto : puestos) {
            // Cuando cambia el número de fila en el archivo, empezamos una fila nueva en pantalla
            if (puesto.getFila() != numeroFilaActual) {
                filaActual = new HorizontalLayout();
                filaActual.setSpacing(false);
                filaActual.getStyle().set("gap", "6px");
                plano.add(filaActual);
                numeroFilaActual = puesto.getFila();
            }

            Registro registro = puesto.buscarRegistroActivo(registros);
            Button boton = crearBotonPuesto(puesto, registro);
            filaActual.add(boton);

            // El Popover se crea después de agregar el botón, cuando el botón ya está en la pantalla
            if (registro != null) {
                crearPopover(boton, registro);
            }
        }
    }

    private Button crearBotonPuesto(Puesto puesto, Registro registro) {
        String letra = puesto.getTipo().equals("CARRO") ? "C" : "M";
        Button boton = new Button(letra + puesto.getFila() + "-" + puesto.getColumna());
        boton.setWidth("3rem");
        boton.getStyle()
                .set("min-width", "0")
                .set("padding", "0")
                .set("font-size", "0.75rem")
                .set("color", "white")
                .set("background-color", registro == null ? COLOR_LIBRE : COLOR_OCUPADO);
        return boton;
    }

    private void crearPopover(Button boton, Registro registro) {
        String tiempo = registro.tiempoTranscurrido(LocalDateTime.now());

        Popover popover = new Popover();
        popover.setTarget(boton);
        popover.add(new VerticalLayout(
                new Span("Placa: " + registro.getPlaca()),
                new Span("Tipo: " + registro.getTipo()),
                new Span("Entró: " + registro.getHoraEntrada().format(Utilidades.FORMATO_FECHA_HORA)),
                new Span("Lleva: " + tiempo)));
    }

    private HorizontalLayout crearLeyenda() {
        HorizontalLayout leyenda = new HorizontalLayout(
                crearEtiquetaDeColor("Libre", COLOR_LIBRE),
                crearEtiquetaDeColor("Ocupado", COLOR_OCUPADO),
                new Span("C = carro, M = moto. Toca un puesto rojo para ver sus datos."));
        leyenda.getStyle().set("flex-wrap", "wrap");
        return leyenda;
    }

    private Span crearEtiquetaDeColor(String texto, String color) {
        Span etiqueta = new Span(texto);
        etiqueta.getStyle()
                .set("background-color", color)
                .set("color", "white")
                .set("padding", "2px 8px")
                .set("border-radius", "4px");
        return etiqueta;
    }
}