import { n as e } from "./chunk-DiqZc92J.js";
//#region node_modules/lit-html/directive.js
var t, n, r, i = e((() => {
	t = {
		ATTRIBUTE: 1,
		CHILD: 2,
		PROPERTY: 3,
		BOOLEAN_ATTRIBUTE: 4,
		EVENT: 5,
		ELEMENT: 6
	}, n = (e) => (...t) => ({
		_$litDirective$: e,
		values: t
	}), r = class {
		constructor(e) {}
		get _$AU() {
			return this._$AM._$AU;
		}
		_$AT(e, t, n) {
			this._$Ct = e, this._$AM = t, this._$Ci = n;
		}
		_$AS(e, t) {
			return this.update(e, t);
		}
		update(e, t) {
			return this.render(...t);
		}
	};
}));
//#endregion
export { t as i, r as n, i as r, n as t };
